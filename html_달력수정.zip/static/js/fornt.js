var checkedCount = function(ele, max){
	var maxCount = max;
	var checkCount = 0;
	var categoryList =document.querySelector(ele);
	var categoryListItem = categoryList.querySelectorAll('li');

	categoryListItem.forEach(function(ele, index){
		categoryListItem[index].querySelectorAll('input').forEach(function(ele, index){
			ele.addEventListener('click' ,function(){
				if(this.checked){
					checkCount++;
					if( maxCount < checkCount){
						layerPopOpen('selectOver');
						checkCount = maxCount;
						this.checked = false;
					}
				} else {
					checkCount--;
				}
			})
		})
	})
}	

/* 레이어 팝업 관련  */
var layPopAction = function(){
	var popBtn = document.querySelectorAll('.btn-layer');
	var layerPop = document.querySelectorAll('.layer-pop');
	
	popBtn.forEach(function(ele,index){
		var layerTarget = ele.getAttribute('data-pop-name')
		ele.addEventListener('click', function(){
			layerPop.forEach(function(ele,index){
				var layerPopName = ele.getAttribute('data-pop-item')
				if(layerPopName == layerTarget) {
					ele.style.display = "block"
				}
			})
		})
	})
	var layerPopCloseBtn = document.querySelectorAll('.pop-footer button');
	layerPopCloseBtn.forEach(function(ele,index){
		ele.addEventListener('click', function(e){
			e.preventDefault();
			this.closest('.layer-pop').style.display= "none";
		})
	})
}


var layerPopOpen = function(item, changeText){
	var layerPop = document.querySelectorAll('.layer-pop');

	layerPop.forEach(function(ele,index){
		var layerPopName = ele.getAttribute('data-pop-item')
		if(layerPopName == item) {
			ele.style.display = "block"
		}
	})
}

/* 탭 관련  */
var tabAction = function(tabName){
	var tabList = document.querySelectorAll('.'+tabName);
	var tabItems = document.querySelectorAll('.tab-item');
	for (let i = 0; i < tabList.length; i++) {
		tabList[i].querySelectorAll('li').forEach(function(ele,index){
			ele.addEventListener('click', function(){
				tabItems.forEach(function(ele,index){
					tabItems[index].classList.remove('active')
				})
				tabItems[index].classList.add('active')
				tabList[i].querySelectorAll("li").forEach(function(ele,index){
					ele.classList.remove('active');
				})
				this.classList.add('active');
			})
		})
	}
}

var selected = function(){
	document.querySelectorAll('select').forEach(function( ele , index){
		ele.addEventListener("change", function(){
			this.classList.add('active');
		})
	})
}
selected();